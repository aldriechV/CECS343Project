const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();

app.use(cors());
app.use(bodyParser.json());

// Set up server to listen on a specific port
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
const db = require('./database');

// Add Tenant Route
app.post('/add_tenant', async (req, res) => {
    const { name, apartment_number } = req.body;

    try {
        const [result] = await db.promise().query('INSERT INTO tenants (name, apartment_number) VALUES (?, ?)', [name, apartment_number]);
        res.status(201).json({ message: 'Tenant added successfully', tenantId: result.insertId });
    } catch (error) {
        console.error('Error in /add_tenant route:', error); // Add this line to log the error
        res.status(500).json({ message: 'Error adding tenant', error });
    }
});


// Add Expense Route
app.post('/add_expense', async (req, res) => {
    const { date, payee, amount, category } = req.body;

    try {
        const [result] = await db.promise().query('INSERT INTO expenses (date, payee, amount, category) VALUES (?, ?, ?, ?)', [date, payee, amount, category]);
        res.status(201).json({ message: 'Expense added successfully', expenseId: result.insertId });
    } catch (error) {
        res.status(500).json({ message: 'Error adding expense', error });
    }
});

// Add Rent Payment Route
app.post('/add_rent_payment', async (req, res) => {
    const { tenant_id, month, amount } = req.body;

    try {
        const [result] = await db.promise().query('INSERT INTO rent_payments (tenant_id, month, amount) VALUES (?, ?, ?)', [tenant_id, month, amount]);
        res.status(201).json({ message: 'Rent payment added successfully', rentPaymentId: result.insertId });
    } catch (error) {
        res.status(500).json({ message: 'Error adding rent payment', error });
    }
});

// View Tenant List Route
app.get('/view_tenant_list', async (req, res) => {
    try {
        const [rows] = await db.promise().query('SELECT * FROM tenants');
        res.status(200).json(rows);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching tenant list', error });
    }
});

// View Expense Report Route
app.get('/view_expense_report', async (req, res) => {
    try {
        const [rows] = await db.promise().query('SELECT * FROM expenses');
        res.status(200).json(rows);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching expense report', error });
    }
});

// View Annual Summary Route
app.get('/view_annual_summary', async (req, res) => {
    try {
        const [incomeRows] = await db.promise().query('SELECT SUM(amount) as total_income FROM rent_payments');
        const [expenseRows] = await db.promise().query('SELECT category, SUM(amount) as total_expense FROM expenses GROUP BY category');
        const totalIncome = incomeRows[0].total_income;
        const expensesByCategory = expenseRows;

        const totalExpenses = expensesByCategory.reduce((acc, expense) => acc + expense.total_expense, 0);
        const netIncome = totalIncome - totalExpenses;

        res.status(200).json({ totalIncome, totalExpenses, expensesByCategory, netIncome });
    } catch (error) {
        res.status(500).json({ message: 'Error fetching annual summary', error });
    }
});
