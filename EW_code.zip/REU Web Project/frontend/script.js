$(document).ready(function () {
    // Add event listener to the Add Tenant form
    $('#add-tenant-form').submit(function (event) {
        event.preventDefault();
        var name = $('#tenant-name').val();
        var apartmentNumber = $('#apartment-number').val();
        $.ajax({
            type: 'POST',
            url: 'http://localhost:3000/add_tenant',
            contentType: 'application/json',
            data: JSON.stringify({
                'name': name,
                'apartment_number': apartmentNumber
            }),
            success: function (response) {
                alert('Tenant added successfully');
            },
            error: function (error) {
                alert('Error adding tenant');
            }
        });
    });

    // Add event listener to the Add Expense form
    $('#add-expense-form').submit(function (event) {
        event.preventDefault();
        var date = $('#expense-date').val();
        var payee = $('#expense-payee').val();
        var amount = $('#expense-amount').val();
        var category = $('#expense-category').val();
        $.ajax({
            type: 'POST',
            url: 'http://localhost:3000/add_expense',
            contentType: 'application/json',
            data: JSON.stringify({
                'date': date,
                'payee': payee,
                'amount': amount,
                'category': category
            }),
            success: function (response) {
                alert('Expense added successfully');
            },
            error: function (error) {
                alert('Error adding expense');
            }
        });
    });

    // Add event listener to the Add Rent Payment form
    $('#add-rent-payment-form').submit(function (event) {
        event.preventDefault();
        var tenantName = $('#rent-payment-tenant').val();
        var month = $('#rent-payment-month').val();
        var amount = $('#rent-payment-amount').val();
        $.ajax({
            type: 'POST',
            url: 'http://localhost:3000/add_rent_payment',
            contentType: 'application/json',
            data: JSON.stringify({
                'tenant_name': tenantName,
                'month': month,
                'amount': amount
            }),
            success: function (response) {
                alert('Rent payment added successfully');
            },
            error: function (error) {
                alert('Error adding rent payment');
            }
        });
    });

    // Add event listener to the View Tenant List form
    $('#view-tenant-list-form').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: 'GET',
            url: 'http://localhost:3000/view_tenant_list',
            contentType: 'application/json',
            success: function (response) {
                // TODO: Display the tenant list in a table or other format
                console.log(response.tenant_list);
            },
            error: function (error) {
                alert('Error getting tenant list');
            }
        });
    });

    // Add event listener to the View Expense Report form
    $('#view-expense-report-form').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: 'GET',
            url: 'http://localhost:3000/view_expense_report',
            contentType: 'application/json',
            success: function (response) {
                // TODO: Display the expense report in a table or other format
                console.log(response.expense_report);
            },
            error: function (error) {
                alert('Error getting expense report');
            }
        });
    });

    // Add event listener to the View Annual Summary form
    $('#view-annual-summary-form').submit(function (event) {
        event.preventDefault();
        $.ajax({
            type: 'GET',
            url: 'http://localhost:3000/view_annual_summary',
            contentType: 'application/json',
            success: function (response) {
                // ToDO: Display the annual summary in a table or other format
                console.log(response.annual_summary);
            },
            error: function (error) {
                alert('Error getting annual summary');
            }
        });
    });
});

